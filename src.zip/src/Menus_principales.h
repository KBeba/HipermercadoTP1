// MENUS.H
#ifndef MENUS_PRINCIPALES_H
#define MENUS_PRINCIPALES_H

// Definición de la estructura Cliente
#include "gestion_de_clientes.h"



// Prototipos de funciones
void menuPrincipal();
void menuAdmin();
void menuEmpleadoCaja();
void mostrAdmins();
void mostrar_menu_empleado_caja(int numero_empleado, int numero_caja);


// Cerrar la guardia de inclusión
#endif // CLIENTES_H
