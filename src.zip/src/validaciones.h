// MENUS.H
#ifndef VALIDACIONES_H
#define VALIDACIONES_H

// Prototipos de funciones
void limpiarBuffer();
int esNumero(const char *str);
void obtenerEntrada(char *mensaje, char *dato, int esNum, int espacios);


// Cerrar la guardia de inclusión
#endif // CLIENTES_H
